import React from 'react'; // 리액트 사용
import {BrowserRouter, Route,Routes} from 'react-router-dom'; // router 설치해야함
import Join from './component/Join';
import Board from './component/Board';
import Download from './component/Download';
import Header from './component/Header';
import Home from './component/Home';
import Stock from './component/Stock';
import Login from './component/Login';
function RouterApp(){
  return(
    <div className='RouterApp'>
      <BrowserRouter>
        <Header/>
        <Routes>
          <Route path='/' exact={true} element={<Home/>}/>
          <Route path='/join' element={<Join/>}/>
          <Route path='/download' element={<Download/>}/>
          <Route path='/board' element={<Board/>}/>
          <Route path='/login' element={<Login/>}/>
          <Route path='/stock' element={<Stock/>}/>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default RouterApp
