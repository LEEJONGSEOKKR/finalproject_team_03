import React from "react";
import '../css/Board.css';
class Board extends React.Component {
    render(){
        return(
            <div>
                <h1>게시판</h1>
            </div>
        );
    }
}
export default Board