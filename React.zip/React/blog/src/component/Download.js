import React from "react";
import '../css/Download.css';

class Download extends React.Component {
    render(){
        return(
          <div>
              <h1>다운로드</h1>
          </div>  
        );
    }
}

export default Download