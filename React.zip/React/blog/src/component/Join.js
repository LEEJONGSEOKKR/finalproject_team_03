import React from "react";
import '../css/Join.css';

class Join extends React.Component {
    render(){

        return (
            <div className="Join__container">
                <p className="Join_name">개인정보 입력란</p>
                <p className="Join_member">
                <div className="Join_icon">ID</div><input id="join_id"/><br/><br/>
                <div className="Join_icon">pw</div><input id="join_pw" type="password"/><br/><br/>
                <div className="Join_icon">Email</div><input id="join_name"/><br/>
                </p>
                <button className="btn btn-info"> 회원가입 </button>
            </div>
        );
    }
}

export default Join