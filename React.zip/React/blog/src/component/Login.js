import React from "react";
import '../css/Login.css';


class Login extends React.Component {
    render(){

        return (
            <div>
                <h1>로그인</h1>
            </div>
        );
    }
}

export default Login