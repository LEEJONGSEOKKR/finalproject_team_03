import React from "react";
import '../css/Stock.css';


class Stock extends React.Component {
    render(){

        return (
            <div className={'row'}>
            
                <h1 className='imputstock'>주식데이터</h1>

            
            <table className={'table'}>
                <tr>
                    <td className="inputstock">
                        <input type={'text'} placeholder='기업 이름을 입력해주세요' className={'input-sm'} size={'25'}/> <button>검색</button>
                    </td>
                </tr>
            </table>
            <table className="main">
                <h1>검색 주가데이터 출력구간</h1>
            </table>
            <table className="sub1">
                <h1>서브1 주가데이터 출력구간</h1>
            </table>
            <table className="sub2">
                <h1>서브2 주가데이터 출력구간</h1>
            </table>
            </div>
        );
    }
}

export default Stock