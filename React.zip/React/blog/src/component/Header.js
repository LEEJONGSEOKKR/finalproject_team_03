import React from "react";
import '../css/Header.css';
import {Link} from 'react-router-dom';



function Header(){
    return (
        <div className='Header'>
            <div className="header_01">
                <Link to="/" style={{ textDecoration: 'none' }}>Home</Link>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <Link to="/login" style={{ textDecoration: 'none' }}>로그인</Link>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <Link to="/join" style={{ textDecoration: 'none' }}>회원가입</Link>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <Link to="/stock" style={{ textDecoration: 'none' }}>주식차트</Link>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <Link to="/download" style={{ textDecoration: 'none' }}>다운로드</Link>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <Link to="/board" style={{ textDecoration: 'none' }}>게시판</Link>
            </div>


        </div>
    );
}
export default Header