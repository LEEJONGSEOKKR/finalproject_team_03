import React from 'react'; // 리액트 사용
import '../css/Home.css';
class Home extends React.Component{

  render(){
    return(
      <div className='main'>
          <h1>home</h1>
      </div>
    );
  }
}
export default Home