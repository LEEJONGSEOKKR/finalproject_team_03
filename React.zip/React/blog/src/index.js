import React from 'react';
import ReactDOM from 'react-dom';
import RouterApp from './RouterApp';


ReactDOM.render( <RouterApp />, document.getElementById('root') );
